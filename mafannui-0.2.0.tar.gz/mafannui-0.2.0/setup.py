from setuptools import setup, find_packages

setup(
    name="MafanNUI",
    version="0.2.0",
    packages=find_packages(),
    install_requires=[
        "PySide6>=6.6.0"
    ],
    author="Mafan Scripts",
    description="Easy Way to create one graphic interface!",
    python_requires='>=3.7',
)