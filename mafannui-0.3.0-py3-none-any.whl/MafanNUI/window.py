#========================================
# Imports
#========================================

import os
import sys

from PySide6 import QtWidgets
from PySide6.QtUiTools import QUiLoader
from PySide6.QtGui import QAction#, QIcon, QKeySequence
from PySide6.QtWidgets import QPushButton,QApplication,QVBoxLayout, QLineEdit, QTextEdit
#========================================
# Global Variables Start
#========================================

loader = QUiLoader()
button = None
uiPath = None
app = None
MainLayout = None
Aplications = QApplication
ChatDisplay = None

#========================================
# Global Variables Ended
#========================================

#========================================
# Utils
#========================================

def getuifile(custompath,path=None):
    if custompath and path is not None:
        return path
    else:
        return os.path.join(os.path.dirname(__file__), "MafanWindow.ui")

# ========================================
# Creation Window
# ========================================

class MafanNUIWindow:
    def __init__(self, title, custompath, path=None):
        self.window = None
        self.title = title
        self.setDefaultSettings()
        if custompath:
            self.window = loader.load(getuifile(True, path), None)
        else:
            print(getuifile(False))
            self.window = loader.load(getuifile(False), None)

        if self.window is None:
            print("Error Window UI ( Window None ) -> Retify the creation of window")
            sys.exit(1)

        self.window.setWindowTitle(str(self.title))
        self.window.setFixedSize(int(self.width), int(self.height))
        self.window.show()

    def returnWindow(self):
        return self.window

    def resizewindow(self,width,height):
        if self.window is not None:
            self.window.setFixedSize(int(width), int(height))
        else:
            print("The window is still None")
            exit("Error number 1")
    @staticmethod
    def startapp(app):
        app.exec()
    def setDefaultSettings(self, width = None, height = None):
        if width is not None:
            self.width = int(width)
        else:
            self.width = int(800)

        if height is not None:
            self.height = int(height)
        else:
            self.height = int(600)

    def getWindowWidth(self):
        return self.width
    def getWindowHeight(self):
        return self.height
# ========================================
# Creation Chat Area
# ========================================
class MafanNUIChat:
    def __init__(self,windowvar,chatdisplay):
        self.window = windowvar
        self.chat = chatdisplay
    def createchatarea(self,readonly):
        global MainLayout
        MainLayout = QVBoxLayout()
        self.chat = QTextEdit()
        self.chat.setReadOnly(readonly)
        MainLayout.addWidget(self.chat)
        central = self.window.centralWidget()
        if central is None:
            central = QtWidgets.QWidget()
            self.window.setCentralWidget(central)
        central.setLayout(MainLayout)
        return ChatDisplay
    def resizechatarea(self,width, height):
        if self.chat is not None:
            self.chat.setFixedSize(int(width), int(height))

class InputText:
    def __init__(self,windowLayout):
        self.window = windowLayout
    def createinputtext(self,placeholdertext):
        input_line = QLineEdit(str(placeholdertext),self.window)
        self.window.addWidget(input_line)

# ========================================
# Creation Toolbar
# ========================================

class Toolbar:
    def __init__(self, windowvar):
        self.window = windowvar
    def createtoolbar(self, title):
        self.toolbar = QtWidgets.QToolBar(str(title), self.window)
        self.window.addToolBar(self.toolbar)
        return self.toolbar

    def createbuttontoolbar(self, title):
        button_action = QAction(title)
        #button_action.setStatusTip("This is your button")
        #button_action.triggered.connect(toolbar_button_clicked)
        self.toolbar.addAction(button_action)

# ========================================
# Creation Button
# ========================================

class MafanNUIButton:
    def __init__(self, windowvar):
        self.window = windowvar
        self.button = None
    def createbutton(self,texto, callback, width, height):
        global MainLayout

        central = self.window.centralWidget()
        if central is None:
            central = QtWidgets.QWidget()
            self.window.setCentralWidget(central)

        # Se não tem layout, cria um QVBoxLayout padrão
        if central.layout() is None:
            MainLayout = QVBoxLayout()
            central.setLayout(MainLayout)

        # Cria o botão e adiciona no layout
        self.button = QPushButton(texto, central)
        self.button.clicked.connect(callback)
        self.button.move(int(width), int(height))  # se quiser posicionamento manual
        self.button.show()


    def resizebutton(self,largura, altura):
        if self.button is not None:
            self.button.setFixedSize(int(largura), int(altura))

    def setbuttonposition(self,buttonvar,width, height):
        if self.button is not None:
            self.button.move(int(width), int(height))

# ========================================
# End
# ========================================