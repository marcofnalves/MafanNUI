from setuptools import setup, find_packages

setup(
    name="MafanNUI",
    version="0.3.0",
    include_package_data=True,
    packages=find_packages(),
    install_requires=[
        "PySide6>=6.6.0"
    ],
    author="Mafan Scripts",
    description="Easy Way to create one graphic interface!",
    python_requires='>=3.7',
)