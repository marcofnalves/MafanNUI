#========================================
# Imports
#========================================

import os
import sys

from PySide6 import QtWidgets
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QPushButton
from PySide6.QtGui import QAction, QIcon, QKeySequence

try:
    from PySide6.QtWidgets import QApplication
except ImportError:
    print("PySide6 não encontrado. Instalando...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "PySide6"])
    from PySide6.QtWidgets import QApplication

#========================================
# Global Variables Start
#========================================

loader = QUiLoader()
windowCreated = None
button = None
uiPath = None
app = None
x = 800
y = 600

def getCreationApp():
    return QApplication
#========================================
# Global Variables Ended
#========================================


#========================================
# Utils
#========================================

def getUIFile(customPath,path=None):
    if customPath and path is not None:
        return path
    else:
        return os.path.join(os.path.dirname(__file__), "MafanWindow.ui")

# ========================================
# Creation Window
# ========================================

def createWindow(title, customPath, path=None):
    global windowCreated
    global x
    global y

    if customPath:
        window = loader.load(getUIFile(True, path), None)
    else:
        print(getUIFile(False))
        window = loader.load(getUIFile(False), None)

    if window is None:
        print("Error Window UI ( Window None ) -> Retify the creation of window")
        sys.exit(1)

    windowCreated = window
    window.setWindowTitle(str(title))
    window.setFixedSize(int(x), int(y))
    window.show()

    return window

def resizeWindow(x_, y_):
    global windowCreated
    windowCreated.setFixedSize(int(x_), int(y_))

def startApp(app):
    app.exec()

# ========================================
# Creation Toolbar
# ========================================

def createToolbar(title):
    global windowCreated
    toolbar = QtWidgets.QToolBar(str(title), windowCreated)
    windowCreated.addToolBar(toolbar)
    return toolbar

def createButtonToolbar(title,toolbar):
    button_action = QAction("Your button", self)
    button_action.setStatusTip("This is your button")
    button_action.triggered.connect(self.toolbar_button_clicked)
    toolbar.addAction(button_action)

# ========================================
# Creation Button
# ========================================

def createButton(texto, callback, x, y):
    global windowCreated
    global button

    central = windowCreated.centralWidget()
    if central is None:
        central = QtWidgets.QWidget()
        windowCreated.setCentralWidget(central)
        central.setLayout(None)  # remove qualquer layout para posicionamento manual

    button = QPushButton(texto, central)
    button.clicked.connect(callback)
    button.move(x, y)
    button.show()

def resizeButton(largura, altura):
    global button
    if button is not None:
        button.setFixedSize(int(largura), int(altura))

def setButtonPosition(x, y):
    global button
    if button is not None:
        button.move(int(x), int(y))

# ========================================
# End
# ========================================


createWindow("Main",False)